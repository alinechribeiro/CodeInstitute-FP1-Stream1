function validaemail(mail){
 	if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(idf.email.value))  
  {  
    alert("valid email"); 
  	idf.submit();
    return (true)  
  }  
    alert( $fullname + "You have entered an invalid email address!")  
    return (false)  
}  
	